<?php
class RequestException extends Exception {}
